﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.ContentSearch.Abstractions;
using Sitecore.ContentSearch.Diagnostics;
using Sitecore.ContentSearch.Linq.Common;
using Sitecore.ContentSearch.Pipelines.QueryGlobalFilters;
using Sitecore.ContentSearch.Security;
using Sitecore.ContentSearch.SolrProvider;
using Sitecore.ContentSearch.Spatial.Indexing;
using Sitecore.ContentSearch.Utilities;
using Sitecore.Diagnostics;

namespace Sitecore.ContentSearch.Spatial.Provider.Solr
{
    public class SolrSearchWithSpatialContext:SolrSearchContext
    {
        private readonly IContentSearchConfigurationSettings contentSearchSettings;
        private readonly SolrSearchIndex index;
        private readonly SearchSecurityOptions securityOptions;
        private IContentSearchConfigurationSettings settings;


        public  SolrSearchWithSpatialContext(SolrSearchIndex index, SearchSecurityOptions options = SearchSecurityOptions.EnableSecurityCheck)
            :base(index,options)
        {
           Assert.ArgumentNotNull(index, "index");
            Assert.ArgumentNotNull(options, "options");
            this.index = index;
            this.contentSearchSettings = this.index.Locator.GetInstance<IContentSearchConfigurationSettings>();
            this.settings = this.index.Locator.GetInstance<IContentSearchConfigurationSettings>();
            this.securityOptions = options;
        }

        public new IQueryable<TItem> GetQueryable<TItem>()
        {
            return this.GetQueryable<TItem>(new IExecutionContext[0]);
        }

        public new IQueryable<TItem> GetQueryable<TItem>(IExecutionContext executionContext)
        {
            return this.GetQueryable<TItem>(new IExecutionContext[] { executionContext });
        }

        public new IQueryable<TItem> GetQueryable<TItem>(params IExecutionContext[] executionContexts)
        {
            LinqToSolrIndexWithSpatial<TItem> index = new LinqToSolrIndexWithSpatial<TItem>(this, executionContexts);
            if (this.contentSearchSettings.EnableSearchDebug())
            {
               ((IHasTraceWriter)index).TraceWriter = new LoggingTraceWriter(SearchLog.Log);
            }
            QueryGlobalFiltersArgs args = new QueryGlobalFiltersArgs(index.GetQueryable(), typeof(TItem), executionContexts.ToList<IExecutionContext>());
            this.Index.Locator.GetInstance<ICorePipeline>().Run("contentSearch.getGlobalLinqFilters", args);
            return (IQueryable<TItem>)args.Query;
        }
    }
}
