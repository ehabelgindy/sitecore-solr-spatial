﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.ContentSearch.Maintenance;
using Sitecore.ContentSearch.Security;
using Sitecore.ContentSearch.SolrProvider;

namespace Sitecore.ContentSearch.Spatial.Provider.Solr
{
    public class SolrSearchIndexWithSpatial : SolrSearchIndex
    {
        public SolrSearchIndexWithSpatial(string name, string core, IIndexPropertyStore propertyStore)
            :base(name,core,propertyStore)
        {

        }

        public override IProviderSearchContext CreateSearchContext(SearchSecurityOptions options = SearchSecurityOptions.EnableSecurityCheck)
        {
            return new SolrSearchWithSpatialContext(this, options);
        }
    }
}
