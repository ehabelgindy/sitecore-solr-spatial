﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.ContentSearch.Linq.Common;
using Sitecore.ContentSearch.Linq.Solr;
using Sitecore.ContentSearch.Spatial.Linq.Nodes;
using SolrNet;

namespace Sitecore.ContentSearch.Spatial.Query
{
    public class SolrQueryMapperWithSpatial : SolrQueryMapper
    {
        private const string GEO_DIST = "geodist({0},{1},{2})";
        private const string GEO_FILT = "{{!geofilt sfield={0} pt={1},{2} d={3}}}";

        public SolrQueryMapperWithSpatial(SolrIndexParameters parameters)
            : base(parameters)
        {
        }

        protected override AbstractSolrQuery Visit(ContentSearch.Linq.Nodes.QueryNode node, SolrQueryMapperState mappingState)
        {
            var withinRadiusNode = node as WithinRadiusNode;
            if (withinRadiusNode != null)
            {
                return VisitWithinRadius(withinRadiusNode, mappingState);
            }
            else
                return base.Visit(node, mappingState);
        }

        protected virtual AbstractSolrQuery VisitWithinRadius(WithinRadiusNode node, SolrQueryMapperState mappingState)
        {
            // Apply radius filter 
            var geoFilter = new SolrQuery(GeoFilter((double)node.Longitude, (double)node.Latitude, (double)node.Radius));
            

            // Sort by distance
            if (node.Sort != SearchTypes.GeoSortDirection.None)
            {
                //SortDirection sort = node.Sort == SearchTypes.GeoSortDirection.Ascending ? SortDirection.Ascending : SortDirection.Descending;
                //Expression<Func<TItem, TItem>> l = n => n;

                //compositeQuery.Methods.Add(new OrderByMethod(GeoFilterContext.CurrentValue.GeoDist(), typeof(string), sort));
                //compositeQuery.Methods.Add(new SelectMethod(l, new string[] { "*", "_dist_:" + GeoFilterContext.CurrentValue.GeoDist() }));
            }

            //return new SolrCompositeQuery(
            //    compositeQuery.Query,
            //    filter,
            //    compositeQuery.Methods,
            //    compositeQuery.VirtualFieldProcessors,
            //    compositeQuery.FacetQueries).q;

            return geoFilter;
        }

        public string GeoDistance(double latitude, double longitude)
        {

            return string.Format(GEO_DIST, Sitecore.ContentSearch.Spatial.Common.Constants.LocationFieldName, latitude, longitude);
        }

        public string GeoFilter(double latitude, double longitude, double distance)
        {
            return string.Format(GEO_FILT, Sitecore.ContentSearch.Spatial.Common.Constants.LocationFieldName, latitude, longitude, distance);
        }
    }
}
