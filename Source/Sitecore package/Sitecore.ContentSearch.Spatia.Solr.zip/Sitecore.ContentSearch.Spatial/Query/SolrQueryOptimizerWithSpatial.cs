﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.ContentSearch.Linq.Solr;
using Sitecore.ContentSearch.Spatial.Linq.Nodes;

namespace Sitecore.ContentSearch.Spatial.Query
{
    public class SolrQueryOptimizerWithSpatial : SolrQueryOptimizer
    {
        protected override Sitecore.ContentSearch.Linq.Nodes.QueryNode Visit(Sitecore.ContentSearch.Linq.Nodes.QueryNode node, SolrQueryOptimizerState state)
        {
            var withinRadiusNode = node as WithinRadiusNode;
            if (withinRadiusNode != null)
            {
                return VisitWithinRadius(withinRadiusNode, state);
            }
            else
                return base.Visit(node, state);
        }


        protected virtual Sitecore.ContentSearch.Linq.Nodes.QueryNode VisitWithinRadius(WithinRadiusNode node, SolrQueryOptimizerState mappingState)
        {
            return new WithinRadiusNode(node.Field, node.Latitude, node.Longitude, node.Radius, node.Sort, mappingState.Boost);
        }
    }
}
