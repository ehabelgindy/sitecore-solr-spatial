﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sitecore.ContentSearch.Spatial.Common
{
    internal static class Constants
    {
        public const String LocationFieldName = "__Location";
    }
}
