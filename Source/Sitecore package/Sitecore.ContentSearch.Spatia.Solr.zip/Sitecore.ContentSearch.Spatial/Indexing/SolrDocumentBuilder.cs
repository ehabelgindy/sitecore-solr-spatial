﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.ContentSearch;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.Configuration;
using Sitecore.Diagnostics;
using Sitecore.ContentSearch.Spatial.Configurations;
using System.Xml;
using Sitecore.Xml;
using Sitecore.ContentSearch.SolrProvider;

namespace Sitecore.ContentSearch.Spatial.Indexing
{
    public class SolrSpatialDocumentBuilder : SolrDocumentBuilder
    {
        private SpatialConfigurations spatialConfigurations;
        public SolrSpatialDocumentBuilder(IIndexable indexable, IProviderUpdateContext context)
            : base(indexable, context)
        {
            BuildSettings();
        }

        public override void AddItemFields()
        {
            base.AddItemFields();
            Item item = (Item)(this.Indexable as SitecoreIndexableItem);
            if (item != null && spatialConfigurations.LocationSettings.Where(i=>i.TemplateId.Equals( item.TemplateID)).Any())
            {
                this.Document.TryAdd(Sitecore.ContentSearch.Spatial.Common.Constants.LocationFieldName, AddPoint(item));
            }
            
        }

        private String AddPoint(Item item)
        {
            var setting = spatialConfigurations.LocationSettings.Where(i => i.TemplateId.Equals(item.TemplateID)).FirstOrDefault();
            if (setting == null)
                return string.Empty;

            double lng = 0;
            double lat = 0;
            if (!string.IsNullOrEmpty(item[setting.LatitudeField]))
            {
                Double.TryParse(item[setting.LatitudeField], out lat);
            }

            if (!string.IsNullOrEmpty(item[setting.LongitudeField]))
            {
                Double.TryParse(item[setting.LongitudeField], out lng);
            }

            if (lng == 0 || lat == 0)
                return String.Empty;
            return lat.ToString() + "," + lng.ToString();
            
        }

        private void BuildSettings()
        {

            spatialConfigurations = new SpatialConfigurations();
            spatialConfigurations.LocationSettings = new List<LocationSettings>();
            XmlNodeList configs = Factory.GetConfigNodes("contentSearchSpatial/IncludeTemplates/Template");

            if (configs == null)
            {
                Log.Warn("sitecore/contentSearchSpatial/IncludeTemplates/Template node was not defined; Please include the Sitecore.ContentSearch.Spatial.config file in include folder.", this);
                return;
            }
            foreach(XmlNode node in configs)
            {
                string templateId = XmlUtil.GetAttribute("id", node);
                string latitudeField = XmlUtil.GetAttribute("LatitudeField", node);
                string longitudeField = XmlUtil.GetAttribute("LongitudeField", node);

                LocationSettings locationSetting = new LocationSettings();
                locationSetting.LatitudeField = latitudeField;
                locationSetting.LongitudeField = longitudeField;
                
                if(ID.IsID(templateId))
                {
                    locationSetting.TemplateId = ID.Parse(templateId);
                }
                spatialConfigurations.LocationSettings.Add(locationSetting);
            }
        }
    }
}