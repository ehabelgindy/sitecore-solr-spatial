﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sitecore.ContentSearch.Linq.Common;
using Sitecore.ContentSearch.Linq.Parsing;
using Sitecore.ContentSearch.Linq.Solr;
using Sitecore.ContentSearch.SolrProvider;
using Sitecore.ContentSearch.Spatial.Parsing;
using Sitecore.ContentSearch.Spatial.Provider.Solr;
using Sitecore.ContentSearch.Spatial.Query;
using SolrNet;

namespace Sitecore.ContentSearch.Spatial.Indexing
{
    public class LinqToSolrIndexWithSpatial<TItem> : Sitecore.ContentSearch.SolrProvider.LinqToSolrIndex<TItem>
    {
        private IExecutionContext[] executionContext { get; set; }
        private SolrSearchContext context { get; set; }

        private QueryMapper<SolrCompositeQuery> queryMapper;
        private SolrQueryOptimizer queryOptimizer;

        private LinqToSolrIndex<TItem> linqToSolrIndex;

        protected override QueryMapper<SolrCompositeQuery> QueryMapper
        {
            get
            {
                return queryMapper;
            }
        }

        protected override IQueryOptimizer QueryOptimizer
        {
            get
            {
                return queryOptimizer;
            }
        }

        public LinqToSolrIndexWithSpatial(SolrSearchWithSpatialContext context)
            : this(context, (IExecutionContext[])null)
        {

            }

        public LinqToSolrIndexWithSpatial(SolrSearchWithSpatialContext context, IExecutionContext executionContext)
            : this (context,new IExecutionContext[] {executionContext}) {
        }


        public LinqToSolrIndexWithSpatial(SolrSearchWithSpatialContext context, IExecutionContext[] executionContext)
            : base(context, executionContext)
        {
            this.context = context;
            this.executionContext = executionContext;

            queryMapper = new Sitecore.ContentSearch.Spatial.Query.SolrQueryMapperWithSpatial(new SolrIndexParameters(context.Index.Configuration.IndexFieldStorageValueFormatter, context.Index.Configuration.VirtualFieldProcessors, context.Index.FieldNameTranslator, executionContext));
            queryOptimizer = new SolrQueryOptimizerWithSpatial();
            linqToSolrIndex = new LinqToSolrIndex<TItem>(context, executionContext);
        }

        public override IQueryable<TItem> GetQueryable()
        {
            base.GetQueryable();
            GenericQueryableWithSpatial<TItem, SolrCompositeQuery> genericQueryable = new GenericQueryableWithSpatial<TItem, SolrCompositeQuery>(linqToSolrIndex, QueryMapper, QueryOptimizer, FieldNameTranslator);
            
            return genericQueryable;
        }
    }
}
