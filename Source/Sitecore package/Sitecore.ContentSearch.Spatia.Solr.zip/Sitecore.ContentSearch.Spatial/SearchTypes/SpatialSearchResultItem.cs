﻿using Sitecore.ContentSearch.SearchTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sitecore.ContentSearch.Spatial.SearchTypes
{
    public class SpatialSearchResultItem: SearchResultItem
    {
        [IndexField(Sitecore.ContentSearch.Spatial.Common.Constants.LocationFieldName)]
        public virtual LocationPoint GeoLocation { get; set; }

        

    }
    public enum GeoSortDirection
    {
        Ascending = 1,
        Descending = 2,
        None = 3
    }
    public class LocationPoint
    {
        /// <summary>
        /// Search results within radius of a specific point
        /// </summary>
        /// <param name="latitude">Latitude of the search point</param>
        /// <param name="longitude">Logitude of the search point</param>
        /// <param name="distance">distance im miles</param>
        /// <returns></returns>
        public bool WithinRadius(double latitude, double longitude, double distance, GeoSortDirection sort = GeoSortDirection.Ascending)
        {
            return true;
        }

    }
}
