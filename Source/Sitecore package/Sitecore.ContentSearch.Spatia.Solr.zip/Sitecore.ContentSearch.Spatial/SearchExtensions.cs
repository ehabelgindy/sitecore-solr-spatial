﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.ContentSearch.Spatial.Indexing;
using Sitecore.ContentSearch.Spatial.Provider.Solr;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Diagnostics;
using Sitecore.ContentSearch.Linq.Common;
using Sitecore.ContentSearch.Utilities;

namespace Sitecore.ContentSearch.Spatial
{
    public static  class SearchExtensions
    {

        public static IQueryable<TResult> GetExtendedQueryable<TResult>(this IProviderSearchContext context)
        {
            return GetExtendedQueryable<TResult>(context, null); 
        }

        public static IQueryable<TResult> GetExtendedQueryable<TResult>(this IProviderSearchContext context, params IExecutionContext[] executionContext)
        
        {
            IQueryable<TResult> queryable;
            var luceneContext = context as SolrSearchWithSpatialContext;
            if (luceneContext != null)
            {
                queryable = GetSolrQueryable<TResult>(luceneContext, executionContext);
            }
            else
            {
                // TODO: Add Solr Support in future
                throw new NotImplementedException("Only Solr is supported");
            }
            ;
            return queryable;
        }

        private static IQueryable<TResult> GetSolrQueryable<TResult>(SolrSearchWithSpatialContext context, IExecutionContext[] executionContext)
        {
            var linqToLuceneIndex = new LinqToSolrIndexWithSpatial<TResult>(context, executionContext);
            if (context.Index.Locator.GetInstance<IContentSearchConfigurationSettings>().EnableSearchDebug())
                ((IHasTraceWriter)linqToLuceneIndex).TraceWriter = new LoggingTraceWriter(SearchLog.Log);
            return linqToLuceneIndex.GetQueryable();
        }

    }
}